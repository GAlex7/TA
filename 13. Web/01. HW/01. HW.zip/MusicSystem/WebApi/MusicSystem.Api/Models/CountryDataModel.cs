﻿namespace MusicSystem.Api.Models
{
    using Infrastructure.Mapping;
    using MusicSystem.Models;
    using System.ComponentModel.DataAnnotations;

    public class CountryDataModel : IMapFrom<Country>
    {
        [Required]
        public string Name { get; set; }
    }
}