﻿namespace MusicSystem.Api.Models
{
    using Infrastructure.Mapping;
    using MusicSystem.Models;
    using System.ComponentModel.DataAnnotations;

    public class ArtistDataModel : IMapFrom<Artist>
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public int CountryId { get; set; }
    }
}