﻿namespace MusicSystem.Api.Models
{
    using Infrastructure.Mapping;
    using MusicSystem.Models;
    using System.ComponentModel.DataAnnotations;

    public class ProducerDataModel : IMapFrom<Producer>
    {
        [Required]
        public string Name { get; set; }
    }
}