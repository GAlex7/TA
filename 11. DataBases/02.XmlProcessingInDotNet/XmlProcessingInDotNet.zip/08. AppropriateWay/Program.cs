﻿namespace _08.AppropriateWay
{
    internal class Program
    {
        public static void Main()
        {
        }
    }
}
